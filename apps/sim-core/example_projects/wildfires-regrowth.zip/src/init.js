/**
 * @param {InitContext} context for initialization
 */
const init = (context) => {

  const gen_tree = () => ({
    "behaviors": [
      "forest.js",
      "@hash/age/age.rs"
    ],
    "color": "green",
    "shape": "xmas-tree",
    "scale": [2, 2],
    "height": 1
  });

  return hstd.init.grid(context.globals().topology, gen_tree);
}
