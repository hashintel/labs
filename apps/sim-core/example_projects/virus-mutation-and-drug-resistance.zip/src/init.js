/**
 * @param {InitContext} context for initialization
 */
const init = (context) => {


  let infected_total = 0;
  const genAgent = () => {
    // Check if more initial infected are needed
    const sick = infected_total < context.globals().infectedCount;
    infected_total = sick ? infected_total + 1 : infected_total;

    let behaviors = ["virus.js", "@hash/random-movement/random_movement.rs"]
    if (sick) { behaviors = ["mutate.js", "virus.js", "@hash/random-movement/random_movement.rs"]; }

    return {
      behaviors,
      sick,
      "strain": sick ? "00" : "",
      "color": sick ? "red" : "green",
      "was_sick": sick ? true : false,
      "sick_time": 0,
      "remaining_immunity": 0
    };
  };

  let agents = hstd.init.scatter(1000, context.globals().topology, genAgent);

  agents.push({
    "behaviors": ["@hash/age/age.rs", "introduce_vaccine.js"],
    "position": [0, 0],
    "age": 0,
    "search_radius": 100,
    "hidden": true,
    "cumulative_infected": 0
  })

  return agents;
}
