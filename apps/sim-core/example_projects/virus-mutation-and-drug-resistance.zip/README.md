This model simulates mutation in viruses and bacteria. Strains compete to infect different people. A vaccine can be introduced at a specific timestep which will provide people with an immunity to any strains with the matching bit in the first character of their identifier.

## Optimization


```video
https://cdn-us1.hash.ai/site/Virus_MDR.mp4
```