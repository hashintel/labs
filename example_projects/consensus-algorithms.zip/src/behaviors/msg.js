/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  // waiting the simulated delay
  if (state.wait > 0) {
    state.wait--;
  } else {
    if (!state.end) {
      // send the message
      state.messages.push(state.m);
      state.end = true;
    } else {
      if (!state.kill) {
        // goes to the position of reciever
        state.position = state.positionTo;
        state.kill = true;
      } else {
        // message agent kills himself
        state.addMessage("hash", "remove_agent");
      }
    }
  }
  // HACK: If uncommented, the message agents disapper from visual representation
  if (context.globals()["hideMessages"]) {
    state.position = null;
  }
};
