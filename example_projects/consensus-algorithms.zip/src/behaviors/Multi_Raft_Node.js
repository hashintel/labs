const CANDIDATE = "candidate";
const FOLLOWER = "follower";
const LEADER = "leader";
const PHASEDEAD = "dead";
const PHASEFINISH = "FinishPhase";
const LeaderRequest = "leaderRequest";
const FollowerResponse = "followerResponse";
const LeaderPrepare = "LeaderPrepare";
const FollowerPrepare = "FollowerPrepare";
const LeaderAcknowledge = "LeaderAcknowledge";
const FollowerAcknowledge = "FollowerAcknowledge";

/**
 * Multi-Raft algorithm
 * 
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  // kill agent if round or step condition is true
  stdlib.killAgentOnCondition(state, context);

  // RAFT algorithm
  if (state.phase != PHASEDEAD && state.role != PHASEFINISH) {
    // algorithm preparation
    const n = context.globals()["numberOfAgents"];
    let allCurrentMessages = context.messages();
    // Timeout update
    state.wait--;
    stdlib.updateTimeout(state)

    // FOLLOWER
    // in this implementation, everyone is all the time a follower
    // If desired differently, uncomment hack in line 62
    // ▷ Choose Leade
    // ▷ Follower Phase 1 - ELECTION PHASE (Follower chooses Leader)
    // Everyone always listens to leader requests.
    // If a new leader requests leadership, everyone needs to answer inspite of the phase the agent is currently in
    let leaderRequests = allCurrentMessages.filter(m => m.type == LeaderRequest && m.data.globalRound >= state.globalRound);
    if (leaderRequests.length > 0) {
      let leaderMessage = stdlib.shuffleArray(leaderRequests)[0];
      state.lastLeaderRequest = leaderMessage;
      state.globalRound = leaderMessage.data.globalRound;
      let newLeader = leaderMessage.data.value;
      if (newLeader != state.agent_name) {
        state.leader = newLeader;
        state.role = FOLLOWER;
        state.voteMessages = [];
        state.wait = state.timeout;
        state.prepared = false;
        SendTo(state, context, FollowerResponse, true, newLeader);
      }
    }

    // Acutal FOLLOWER ROLE
    // if desired, the follower phase can be seperated. The code will produce the smae results.
    // Maybe it increases efficiency, but this way it increases the possiblity to find consesus,
    // because in a non-byzantine environment it's possible to assume, that only messages will
    // be sent from leaders, if their conditions are met. Therefore this implementation ensures
    // stabilty, becauseeven if a Follwer (or Leader) wasn't prepared it ensures every agent is on
    // the same page.
    // HACK: if (state.role == FOLLOWER)
    {
      state.color = state.leader == null ? context.globals()["colorUnkown"] : context.globals()["colorFollower"];
      // if timout is not expired
      if (state.wait > 0) {
        // ▷ Follower Phase 2 - PREPARE
        state.height = state.leader == null ? context.globals()["phase0Height"] : context.globals()["phase1Height"];
        // 21: wait for messages of the form (leaderP repare, v, globalRound) for the time of timeoutp
        let leaderPrepareMessages = allCurrentMessages.filter(m => {
          let typeCheck = m.type == LeaderPrepare;
          let globalRoundCheck = m.data.globalRound >= state.globalRound;
          return typeCheck && globalRoundCheck;
        });
        // if recieved at least one message then
        if (leaderPrepareMessages.length > 0) {
          let leaderMessage = leaderPrepareMessages[0];
          state.leader = leaderMessage.data.frm;
          // temporaryDecided ← v
          state.temporaryDecided = leaderMessage.data.value;
          // send (followerPrepare, true, globalRound) back to Leader process
          SendTo(state, context, FollowerPrepare, true, state.leader);
          state.wait = state.timeout + 1;
          state.prepared = true;
        }

        if (state.prepared) {
          state.height = context.globals()["phase2Height"];
        }

        // ▷ Follower Phase 3 - ACKOWLEDGE
        // wait for messages of the form (leaderAcknowledge, x, globalRound) for the time of timeoutp
        let leaderAcknowledgeMessages = allCurrentMessages.filter(m => {
          let typeCheck = m.type == LeaderAcknowledge;
          let globalRoundCheck = m.data.globalRound >= state.globalRound;
          return typeCheck && globalRoundCheck;
        });
        // if recieved at least one message then
        if (leaderAcknowledgeMessages.length > 0) {
          state.height = context.globals()["phase3Height"];
          let leaderMessage = leaderAcknowledgeMessages[0];
          // decided ← temporaryDecided
          let decisionValue = state.temporaryDecided
          let globalRound = leaderMessage.data.globalRound;
          state.leader = leaderMessage.data.frm;
          // decidedp ← x
          state.decided = decisionValue;
          // decidedListp[globalRound] ← decidedp
          state.decidedList[globalRound] = decisionValue;
          // send (followerAcknowledge, true, globalRound) back to Leader process
          SendTo(state, context, FollowerAcknowledge, true, state.leader);
          if (state.xValueList.length == state.decidedList.length) {
            // return decidedListp
            state.addMessage("gamemaster", "decided", {
              "frm": state.agent_name,
              "decidedList": state.decidedList,
              "role": FOLLOWER
            });
            state.role = PHASEFINISH;
          }
          // init new globalRound
          state.globalRound = globalRound + 1;
          state.wait = state.timeout + 1;
          state.prepared = false;
        }
      }

      // if timeout is expired
      // else role ← Candidate
      else if (state.role != LEADER) {
        state.role = CANDIDATE;
        state.wait = 0;
      }
    }

    // PHASE 1 - ELECTION PHASE (Candidate)
    // ▷ Leader Phase 1
    if (state.role == CANDIDATE) {
      state.color = context.globals()["colorCandidateProposer"];
      if (state.wait < 1) {
        // send (leaderRequest, globalRound) to all processes
        Send(state, context, LeaderRequest, state.agent_name);
        state.voteMessages = [];
        state.leader = null;
        state.wait = state.timeout;
        //state.role = FOLLOWER;
      } else {

        // wait for messages of the form (leaderP repare, globalRound) for the time of timeoutp
        let voteMessages = allCurrentMessages.filter(m => m.type == FollowerResponse && m.data.value);
        state.voteMessages = state.voteMessages.concat(voteMessages);
        // if recieved more than k/2 messages with (f ollowerResponse, true, globalRound) then
        if (state.voteMessages.length + 1 > (n / 2)) {
          // role ← Leader
          state.role = LEADER;
          state.leader = state.agent_name;
          state.wait = null; // To know, if entering a wait funciton for the first time
        }
      }
    }

    // LEADER
    if (state.role == LEADER) {
      // update view
      state.color = context.globals()["colorLeader"];

      // wait for messages of the form (f ollowerP repare, ∗, globalRound) for the time of timeoutp
      let newPreparedMsgs = allCurrentMessages.filter(m => m.type == FollowerPrepare && m.data.globalRound == state.globalRound);
      state.preparedMsgs = state.preparedMsgs.concat(newPreparedMsgs);
      let preparedMsgs = state.preparedMsgs;

      // wait for messages of the form (f ollowerAcknowledge, ∗, globalRound) for the time of timeoutp
      let newAcknowledgedMsgs = allCurrentMessages.filter(m => m.type == FollowerAcknowledge && m.data.globalRound == state.globalRound);
      state.acknowledgedMsgs = state.acknowledgedMsgs.concat(newAcknowledgedMsgs);
      let acknowledgedMsgs = state.acknowledgedMsgs;

      // If not all decisions made
      if (state.decidedList.length < state.xValueList.length) {
        // 2 PHASE COMMIT

        // x is wanted decisionValue
        let x = state.xValueList[state.globalRound];
        // temporaryDecidedp ← x
        state.temporaryDecided = x;


        // ▷ Leader Phase 2 - PREPARE
        if (preparedMsgs.length + 1 < n / 2) {
          if (state.prepared == null && preparedMsgs.length == 0 || state.wait < 0) {
            state.prepared = true;
            // send (leaderPrepare, globalRound) to all processes
            Send(state, context, LeaderPrepare, x);
            state.wait = state.timeout;
            state.preparedMsgs = [];
          }
        }

        // if recieved more than k/2 messages with (f ollowerP repare, true, globalRound) then
        else {
          // ▷ Leader Phase 3  - ACKNOwLEDGE

          // decided ← temporaryDecidedp, decidedListp[globalRound] ← decidedp
          state.decided = state.temporaryDecided;
          state.decidedList[state.globalRound] = state.temporaryDecided;

          // If less than n/2 acknowledged messages recieved
          if (acknowledgedMsgs.length + 1 < n / 2) {

            if (state.ackknowledge == null && acknowledgedMsgs.length == 0 || state.wait < 0) {


              state.ackknowledge = true;
              // send (leaderAcknowledge, x, globalRound) to all processes
              Send(state, context, LeaderAcknowledge, x);
              state.wait = state.timeout;
              state.acknowledgedMsgs = [];
            }
          }
          // if recieved more than k/2 messages with (followerAcknowledge, true, globalRound) then
          else {


            // inite next global round
            state.globalRound++;
            state.prepared = null;
            state.ackknowledge = null;
            state.preparedMsgs = [];
            state.acknowledgedMsgs = [];

            // If leader should change after one decision (forced 3PC instead of 2PC)
            if (context.globals()["leaderDecidesOnlyOneValue"]) {
              state.role = FOLLOWER
              // optional : if timoutChangeAfterLeaderDecided > 0 the probabilty of a leaderchange is being favored
              if (context.globals()["timoutChangeAfterLeaderDecided"] != null) {
                state.wait = state.timeout + context.globals()["timoutChangeAfterLeaderDecided"];
              } else {
                state.wait = state.timeout;
              }
            } else {
              state.wait = state.timeout;
            }

          }
        }
      }

      // Finished all decisions
      if (state.decidedList.length == state.xValueList.length) {
        if (state.xValueList.length == state.decidedList.length) {
          // return decidedListp
          state.addMessage("gamemaster", "decided", {
            "frm": state.agent_name,
            "decidedList": state.decidedList,
            "role": LEADER
          });
          state.role = PHASEFINISH;
          state.height = context.globals()["phase3Height"];;
        }
      }

    }
  }
};

/**
 * Sends a message to all agents
 * 
 * @param {string} R kind of message
 * @param {AgentState} state of the agent
 */
function Send(state, context, type, value) {
  const n = context.globals()["numberOfAgents"];
  for (let reciever = 0; reciever < n; reciever++) {
    if (reciever != state.agent_name) {
      SendTo(state, context, type, value, reciever);
    }
  }
};


/**
 * Sends a message to specific agent
 */
function SendTo(state, context, type, value, reciever) {
  let msg = getMessage(state, type, value, reciever);
  let messageAgent = stdlib.getMessageAgent(state, msg, reciever);
  state.addMessage("hash", "create_agent", messageAgent);
}

function getMessage(state, type, value, reciever) {
  let msg = {
    to: reciever,
    type: type,
    data: {
      frm: state.agent_name,
      value: value,
      globalRound: state.globalRound,
      type: type
    },
  };
  return msg;
}