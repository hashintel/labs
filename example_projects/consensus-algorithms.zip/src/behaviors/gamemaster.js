const ENDPHASE = "endPhase";

/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  const n = context.globals()["numberOfAgents"];
  state.allMessages = state.allMessages.concat(context.messages());
  let maxDeadAgents = Math.floor((Object.keys(context.globals()["agentDeaths"] ?? 0).length+1) / 4);
  let acceptanceThreshold = Math.max(context.globals()["acceptanceThreshold"], maxDeadAgents);
  let resultList = state.resultLists.find(s => s);

  state.acceptanceThreshold = acceptanceThreshold;

  if (state.phase != ENDPHASE) {

    context.messages().forEach(m => {
      state.resultLists[m.data.frm] = m.data.decidedList;
    });


    // if all messages arrived
    let falseMessages = 0;
    for (i = 0; i < n; i++) {
      if (state.resultLists[i] == null) {
        falseMessages++;
      }
    }

    // if enough decidedLists recieved
    if (falseMessages <= acceptanceThreshold && resultList != null) {
      // "print" resultList
      var blockList = stdlib.buildBinaryBlocks(resultList, [0, 0]);
      blockList.forEach(block => {
        state.addMessage("hash", "create_agent", block);
      });
      state.blockList = blockList;
      state.phase = ENDPHASE;
    }
  } else {
    state.color = "white";

    let algorithmName = "no algorithmName";
    switch (context.globals()["algorithm"]) {
      case 0:
        algorithmName = "Multi-Ben-Or";
        break;
      case 1:
        algorithmName = "Multi-Paxos";
        break;
      case 2:
        algorithmName = "Multi-Raft";
        break;
    }

    let rsn = algorithmName + " consensus: [" + resultList
      + "], \n acceptanceThreshold: " + (acceptanceThreshold);
    state.addMessage("hash", "stop", {
      status: "success", reason: rsn
    });
  }


};
