// Messages
const PREPARE = "prepareMSG";
const PROMISE = "promiseMSG";
const ACCEPT = "acceptMSG";
const ACCEPTED = "acceptedMSG";
// Roles
const PROPOSER = "proposer";
const LEARNER = "learner";
const ACCEPTOR = "acceptor";
// Phases
const PHASEACCEPTOR = "acceptorPhase";
const PHASE1 = "promisePhase";
const PHASE2 = "acceptPhase";
const PHASEDEAD = "dead";
const PHASEFINISH = "FinishPhase";

/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  stdlib.killAgentOnCondition(state, context);
  stdlib.updateTimeout(state);

  // numberOfAgents = k from Pseudocode
  const numberOfAgents = context.globals()["numberOfAgents"];
  const MINAGREEABLEAGENTS = (numberOfAgents / 2); // +1 comes from self
  state.allCurrentMessages = context.messages();
  stdlib.allMessagesUpdate(state, context);
  if (state.phase != PHASEDEAD && state.phase != PHASEFINISH) {

    // Choose Leader
    // PROMISE - Acceptor Phase 1
    let unsortedPrepareMsgs = state.allCurrentMessages.filter(m => m.type == PREPARE && m.data.globalRound == state.globalRound);
    // (Always) listen for messages of the form (leaderRequest, proposedN, r, globalRound) from any processe
    let prepareMsgs = sortMsgsByProposedN(unsortedPrepareMsgs);
    state.height = context.globals()["phase1Height"];
    if (prepareMsgs.length > 0) {
      prepareMsgs.forEach(m => {
        let msgData = m.data;
        let proposedN = msgData.n;
        // PROMISE Conditions
        let noPromisedNYet = state.promisedN == null;
        let promisedNIsSmallerThanProposedN = state.promisedN != null && parseInt(state.promisedN) < parseInt(proposedN);
        // Approve PROMISE
        // if recieved at least one message with promisedN < proposedN then
        if (noPromisedNYet || promisedNIsSmallerThanProposedN) {
          state.phase = PHASEACCEPTOR;
          state.role = ACCEPTOR;
          state.wait = state.timeout;
          state.promisedN = parseInt(proposedN); // Integer save
          state.leader = msgData.frm;
          state.round = msgData.round;
          state.globalRound = msgData.globalRound;
          SendTo(state, PROMISE, true, msgData.frm, state.promisedN);
        }
        // Disapprove PROMISE (for faster progress in asynchronus system)
        else {
          SendTo(state, PROMISE, false, msgData.frm, state.promisedN);
        }
      });
    }

    // ▷ Acceptor
    if (state.role == ACCEPTOR) {
      state.height = context.globals()["phase2Height"]; // indicate phase 2 (Waiting for Acceptmessage)
      state.color = context.globals()["colorFollower"];
      //▷ Acceptor Phase 2 ◁
      if (state.wait > 0 && state.leader != null) {
        // ACCEPT - Acceptor Phase 2
        // wait for messages of the form (Accept, promisedN, v, r, globalRound) for the time of timeoutp
        let acceptMsgs = state.allCurrentMessages.filter(m => m.type == ACCEPT && m.data.globalRound == state.globalRound);
        if (acceptMsgs.length > 0) {
          acceptMsgs.forEach(m => {
            let msgData = m.data;
            let sender = msgData.frm;
            let proposedN = parseInt(msgData.n);
            let msgRound = msgData.round;
            let proposedValue = msgData.value;
            // ACCEPT Conditions
            let noPromisedNYet = state.promisedN == null;
            let promisedNIsSmallerThanOrEqualProposedN = state.promisedN != null && parseInt(state.promisedN) <= parseInt(proposedN);
            // Approve ACCEPT
            if (noPromisedNYet || promisedNIsSmallerThanOrEqualProposedN) {
              if (state.decided == null) {
                state.wait = state.timeout;
                // decidedp ← v, decidedListp[globalRound] ← decidedp
                state.decided = proposedValue;
                state.decidedList = state.decidedList.concat([state.decided]);
                // send (Accepted, true, r, globalRound) back to proposer process
                SendTo(state, ACCEPTED, true, msgData.frm);
                // if all decisions made
                if (state.xValueList.length == state.decidedList.length) {
                  // return decidedListp
                  state.addMessage("gamemaster", "decided", {
                    "frm": state.agent_name,
                    "decidedList": state.decidedList,
                    "role": ACCEPTOR
                  });
                  state.phase = PHASEFINISH;
                  state.height = context.globals()["phase3Height"];
                } else {
                  // reset agent for next round
                  state.globalRound++; // Round to work on values
                  state.phase = PHASEACCEPTOR; // Starting Phase
                  state.round = 0; // Starting round
                  state.decided = null; // No value decided yet
                }
              }
            }
            // Disapprove ACCEPT
            else {
              // TODO: NOT RIGHT
              // SendTo(state, context, ACCEPTED, state.roundID, msgData.frm);
            }
          });
        }
      } else {
        state.role = PROPOSER;
        state.phase = PHASE1;
        state.wait = 1;
        state.leader = null;
      }
    }

    // ▷ Proposer
    if (state.role == PROPOSER) {
      state.color = context.globals()["colorCandidateProposer"];
      // wait for messages of the form (promise, ∗, r, globalRound) for the time of timeoutp
      let newPromisedMsgs = state.allCurrentMessages.filter(m => m.type == PROMISE && m.data.globalRound == state.globalRound);
      state.promisedMsgs = state.promisedMsgs.concat(newPromisedMsgs);
      let promisedMsgs = state.promisedMsgs;
      let truePromisedMsgs = promisedMsgs.filter(m => m.data.value == true);
      if (state.phase == PHASE1) {
        // if recieved more than k/2 messages with (promise, true, r, globalRound) then
        if (state.decided == null && truePromisedMsgs.length + 1 > MINAGREEABLEAGENTS) {
          state.phase = PHASE2;
          state.wait = 0;
        } else {
          // ▷ Proposer Phase 1
          state.height = context.globals()["phase1Height"];  // indicate phase 1
          // Send PREPARE message
          if (state.wait < 1) {
            // New round preperation
            state.wait = state.timeout;
            state.promisedMsgs = []; // clear promised Msgs
            state.round++; // Add round

            // proposedN ← getU niqueN (k, r, globalRound, agentID)
            state.proposedN = (numberOfAgents - 1) * state.globalRound + (numberOfAgents - 1) * state.round + state.agent_name; // unique request identifier
            state.promisedN = state.proposedN;
            // send (leaderRequest, proposedN, r, globalRound) to all processes
            Send(state, context, PREPARE, 'Promised N message');
          }
        }
      }
      // ▷ Proposer Phase 2
      if (state.phase == PHASE2) {
        state.color = context.globals()["colorLeader"];
        state.height = context.globals()["phase2Height"];; // indicate phase 2

        if (state.wait < 1) {
          // x ← valueListp[globalRound]
          state.x = state.xValueList[state.globalRound];
          // send (Accept, promisedN, x, r, globalRound) to all processes
          Send(state, context, ACCEPT, state.x);
          // RESET
          state.wait = state.timeout;
        }

        // wait for messages of the form (Accepted, ∗, r, globalRound) for the time of timeoutp
        let newAcceptedMsgs = state.allCurrentMessages.filter(m => m.type == ACCEPTED && m.data.globalRound == state.globalRound);
        state.acceptedMsgs = state.acceptedMsgs.concat(newAcceptedMsgs);
        let acceptedMsgs = state.acceptedMsgs;
        let trueAcceptedMsgs = acceptedMsgs.filter(m => m.data.value == true);
        //if recieved more than k/2 messages with (Accepted, true, r, globalRound) then
        if (trueAcceptedMsgs.length + 1 > MINAGREEABLEAGENTS) {
          // decided ← x
          state.decided = state.x;
          // decidedListp[globalRound] ← decidedp
          state.decidedList = state.decidedList.concat([state.decided]);
          state.wait = state.timeout;
          // Start new global round (Reset values)
          if (state.globalRound + 1 < state.xValueList.length) { // TODO: Check equation
            // init next round
            state.globalRound++;
            state.phase = PHASE1; // Starting Phase
            state.round = 0; // Starting round
            // x ← valueListp[globalRound]
            state.x = state.xValueList[state.globalRound];
            state.decided = null; // decided reset

            // state.promisedN and state.promisedMsgs won't be reset. Therefore the promised message from
            // last round are staying and only the acceptRequests are being sent
            state.acceptedMsgs = [];
            

            // Visuals
            state.wait = 1;

            // If leader should change after one decision (forced 3PC instead of 2PC)
            if (context.globals()["leaderDecidesOnlyOneValue"]) {
              state.promisedMsgs = [];
              if (context.globals()["timoutChangeAfterLeaderDecided"] != null) {
                state.wait = state.timeout + context.globals()["timoutChangeAfterLeaderDecided"];
              } else {
                state.wait = state.timeout;
              }
            }

          }
          // End whole simulation
          else {
            // return decidedListp
            state.addMessage("gamemaster", "decided", {
              "frm": state.agent_name,
              "decidedList": state.decidedList,
              "role": PROPOSER
            });
            state.phase = PHASEFINISH;
            state.height = context.globals()["phase3Height"];
          }
        }
      }
    }

    // timeout update
    state.wait--;
  }
}

/**
 * @param {string} R kind of message
 * @param {AgentState} state of the agent
 */
function Send(state, context, type, value) {
  const numberOfAgents = context.globals()["numberOfAgents"];
  for (let reciever = 0; reciever < numberOfAgents; reciever++) {
    if (reciever != state.agent_name) {
      SendTo(state, type, value, reciever);
    }
  }
};

function SendTo(state, type, value, reciever) {
  let msg = getMessage(state, type, value, reciever);
  let messageAgent = stdlib.getMessageAgent(state, msg, reciever);
  state.addMessage("hash", "create_agent", messageAgent);

}

function getMessage(state, type, value, reciever) {
  let msg = {
    to: reciever,
    type: type,
    data: {
      frm: state.agent_name,
      value: value,
      round: state.round,
      globalRound: state.globalRound,
      n: state.promisedN,
      type: type
    },
  };
  return msg;
}

/**
 * Sorts given array by their n.
 * 
 * This is important, due to that hash has no real time measurement.
 * So in one step multiple messages can arrive, but when the agent behaves
 * on multiple messages in the same step and accepts the n of 2 agents at
 * the same "time", 2 proposers will think they are accepted. By sorting
 * the array we know there will be at most one n accepted per step.
 * 
 * @param {array} msgArray 
 * @returns {array}
 */
function sortMsgsByProposedN(msgArray) {
  let sortedMsgArray = msgArray.sort((a, b) => b.data.n - a.data.n);
  return sortedMsgArray;
}