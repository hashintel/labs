/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  let allMessages = context.messages();
  let heightMessages = allMessages.filter(m => m.type = "height")
  if (heightMessages.length > 0) {
    state.timeout = heightMessages[0].data.value;
    state.height = heightMessages[0].data.value * context.globals()["objectsMaxHeight"] / state.maxTimeout;
  }
};
