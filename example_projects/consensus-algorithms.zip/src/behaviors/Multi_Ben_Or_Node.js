const PHASE0 = "p0";
const PHASE1 = "p1";
const PHASE2 = "p2";
const PHASEDECIDED = "decidePhase";
const PHASEFINISH = "FinishPhase";
const PHASEDEAD = "dead";
const R = "R";
const P = "P";

/**
 * Multi-Ben-Or algorithm
 * 
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  // update inbox
  stdlib.allMessagesUpdate(state, context);
  // kill agent if round or step condition is true
  stdlib.killAgentOnCondition(state, context);


  // main algorithm
  const numberOfAgents = context.globals()["numberOfAgents"];
  var f = context.globals()["f"];
  const maxF = Math.floor((numberOfAgents-1) / 2);
  if (f < 0 || f > maxF) {
    f = maxF;
  }
  state.f = f;

  // Phase 0
  if (state.phase == PHASE0) {
    // init round, update view
    state.height = context.globals()["phase0Height"];
    state.round = state.round + 1;
    state.color = stdlib.getColor(state.x);
    Send(state, context, R, state.x);

    // init first phase
    state.phase = PHASE1;
  }
  // Phase 1
  else if (state.phase == PHASE1) {
    // wait for messages of the form (R, r, globalRound, *) from k − f processes
    state.Rmsg = waitMessages(state, R);
    if (state.Rmsg.length >= (numberOfAgents - f)) {
      for (i = 0; i < context.globals()["valueIntervalSize"]; i++) {
        // if recieved more than k/2 (R, k, v) with the same v then
        let rMsgs = state.Rmsg.filter(msg => msg.data.value == i);
        if (rMsgs.length > (numberOfAgents / 2)) {
          state.x = i;
          Send(state, context, P, i);
          // init next phase
          state.phase = PHASE2;
        }
      }

      // else send (R, r, globalRound, ?) to all processes
      if (state.phase == PHASE1) {
        state.x = -1;
        Send(state, context, P, -1)
        // init next phase
        state.phase = PHASE2;
      }


    }
    // update view
    state.height = context.globals()["phase1Height"];
    state.color = stdlib.getColor(state.x);
  }
  // Phase 2
  else if (state.phase == PHASE2) {
    // update view
    state.height = context.globals()["phase2Height"];
    state.color = stdlib.getColor(state.decided ?? state.x);

    // wait for messages of the form (P, r, globalRound, ∗) from k − f processes
    state.Pmsg = waitMessages(state, P);
    if (state.Pmsg.length >= (numberOfAgents - f)) {
      // if recieved at least f + 1 (P, r, globalRound, v) with the same v ̸= ? 
      for (i = 0; i < context.globals()["valueIntervalSize"]; i++) {
        let pMsgs = state.Pmsg.filter(msg => msg.data.value == i);
        if (pMsgs.length >= (f + 1)) {
          // decide
          state.decided = i;
          // init end phase
          state.phase = PHASEDECIDED;
          break;
        }
      }
      // else if at least one (P, r, globalRound, ∗) with v ̸= ?
      if (state.phase == PHASE2) {
        for (i = 0; i < context.globals()["valueIntervalSize"]; i++) {
          let pMsgs = state.Pmsg.filter(msg => msg.data.value == i);
          if (pMsgs.length > 0) {
            state.x = i;
            // init next round
            state.phase = PHASE0;
            state.phase0Reason = "Least " + (pMsgs.length) + ", Type: " + i;
            break;
          }
        }
      }
      // else random
      if (state.phase == PHASE2) {
        state.x = stdlib.random(context.globals()["valueIntervalSize"]);
        // init next round
        state.phase = PHASE0;
        state.phase0Reason = "Random, Type: " + state.x;
      }
    }
  }

  // PHASEDECIDED
  if (state.phase == PHASEDECIDED && state.decided != null) {
    // update view
    state.height = context.globals()["phase3Height"];
    state.color = stdlib.getColor(state.decided);

    // decide
    state.decidedList = state.decidedList.concat(state.decided)

    // if not all decisions made
    if (state.decidedList.length < state.xValueList.length) {
      // init next global round
      let nextGlobalRound = state.globalRound + 1;
      state.globalRound = nextGlobalRound;
      state.x = state.xValueList[nextGlobalRound];
      state.decided = null;
      state.phase = PHASE0;
      state.round = 0;
      // Hack: if performance is very bad, "state.allMessages = [];" can be added, but the algorithm is less stable
    }
    // else if finished all decisions
    else {
      // return decidedListp
      state.addMessage("gamemaster", "decided", {
        "frm": state.agent_name,
        "decidedList": state.decidedList
      });
      // wait for others to finish deciding
      state.phase = PHASEFINISH;
    }
  }
};

/**
 * Sends to every agent a message
 * 
 * @param {AgentState} state state of the agent
 * @param {AgentContext} context context of the agent
 * @param {string} type kind of message
 * @param {string} value value in the message
 */
function Send(state, context, type, value) {
  const n = context.globals()["numberOfAgents"];
  for (let reciever = 0; reciever < n; reciever++) {
    //  actual message that the agents should recieve
    let msg = {
      to: reciever,
      type: type,
      data: {
        value: value,
        round: state.round,
        globalRound: state.globalRound,
        type: type,
        frm: state.agent_name
      },
    };

    // Create message agent with necessary parameters and msg in m
    let messageAgent = stdlib.getMessageAgent(state, msg, reciever);

    state.addMessage("hash", "create_agent", messageAgent);
  }
};

/**
 * Filters all messages for globalRound, round and given message type and returns the filtered message list.
 * 
 * @param {AgentState} state of the agent
 * @param {string} type message type (R or P)
 */
function waitMessages(state, type) {
  // Filter all the messages for the desired conditions
  let allMessagesForThisGlobalRound = state.allMessages.filter((msg) => msg.data.globalRound == state.globalRound);
  let allMessagesForThisRound = allMessagesForThisGlobalRound.filter((msg) => msg.data.round == state.round);
  let messagesWithType = allMessagesForThisRound.filter((msg) => msg.type == type);
  let messagesWithoutOwn = messagesWithType.filter((msg) => msg.data.frm != state.agent_name);
  return stdlib.shuffleArray(messagesWithType);
}