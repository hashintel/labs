// Constant names
const PHASEDEAD = "dead";
const PROPOSER = "proposer";
const LEARNER = "learner";
const ACCEPTOR = "acceptor";
const PHASE1 = "promisePhase";
const PHASEACCEPTOR = "acceptorPhase";
const PREPARE = "prepareMSG";
const PROMISE = "promiseMSG";
const ACCEPT = "acceptMSG";
const ACCEPTED = "acceptedMSG";
const LeaderRequest = "leaderRequest";
const FollowerResponse = "followerResponse";
const LeaderPrepare = "LeaderPrepare";
const FollowerPrepare = "FollowerPrepare";
const LeaderAcknowledge = "LeaderAcknowledge";
const FollowerAcknowledge = "FollowerAcknowledge";

var globals;      // global access on globals without context
var random;       // global access for random function
var radius;       // global access for radius
var agentDeaths;  // global access for agentDeaths

/**
 * Init the whole simulation. Needs to return an array of agents to run a simulation. (Hash specification)
 * Creates agentarray based on the parameters in globals.
 * Initializes global functions stdlib hack.
 * 
 * @param {InitContext} context for initialization
 */
const init = (context) => {
  globals = context.globals();

  // init random function
  let seed = cyrb128(globals["seed"]);
  random = xoshiro128ss(seed[0], seed[1], seed[2], seed[3]);
  // init vars and consts from globals
  // Note: it is important, that this function is the first function using random being called after the initialization of random
  let xValueLists = GetXValueLists();
  radius = globals["numberOfAgents"];
  const algorithm = globals["algorithm"];

  InitAgentDeathObject();

  // Create agentList by algorithm
  let agents = []
  switch (algorithm) {
    case 0:
      agents = StartMultiBenOr(xValueLists);
      break;
    case 1:
      agents = StartMultiPaxos(xValueLists);
      break;
    case 2:
      agents = StartMultiRaft(xValueLists);
      break;
    case 3:
      agents = StartMessageDelayDistributionTest();
      break;

  }

  initGlobalFunctions();

  // build visualization of inputs
  if (globals["showInputblocks"] && algorithm < 3) {
    agents = agents.concat(GetInputvalueBlocks(xValueLists));
  }


  return agents;
}


// #region Start Algorithm Functions



/**
 * Function to start Multi-Ben-Or Algorithm.
 */
function StartMultiBenOr(xValueLists) {
  let agents = [];

  // Create Nodes
  for (let i = 0; i < globals["numberOfAgents"]; i++) {
    let xValueList = xValueLists[i];
    let agent = GetMultiBenOrAgent(i, xValueList);
    agent = DoomAgent(agent);

    agents.push(agent);
  }

  // add gamemaster
  agents.push(GetGameMaster())
  return agents;
}

// MULTI PAXOS
function StartMultiPaxos(xValueLists) {
  const numberOfAgents = globals["numberOfAgents"];
  let agents = [];

  // Get Acceptors
  for (let i = 0; i < numberOfAgents; i++) {
    let xValueList = xValueLists[i];
    let acceptorAgent = GetMultiPaxosAgent(i, ACCEPTOR, xValueList);
    acceptorAgent = DoomAgent(acceptorAgent);
    agents.push(acceptorAgent);
  }

  let timeoutNodes = getTimeoutNodes(agents);
  agents = agents.concat(timeoutNodes);

  // add gamemaster
  agents.push(GetGameMaster())

  return agents;
}

// MULTI RAFT
function StartMultiRaft(xValueLists) {
  const numberOfAgents = globals["numberOfAgents"];
  let agents = [];
  let timeoutList = GetTimeoutList();
  // create agents
  for (let i = 0; i < numberOfAgents; i++) {
    let xValueList = xValueLists[i];
    let raftNode = GetMultiRaftAgent(i, xValueList, timeoutList[i])
    raftNode = DoomAgent(raftNode);
    agents.push(raftNode);
  }

  let timeoutNodes = getTimeoutNodes(agents);
  agents = agents.concat(timeoutNodes);

  // add gamemaster
  agents.push(GetGameMaster())

  return agents;
}

function getTimeoutNodes(agents) {
  let timeoutAgents = [];
  if (!globals["hideTimouts"]) {
    const maxTimeout = [].concat(agents).sort((a, b) => b.timeout - a.timeout)[0].timeout;
    for (let i = 0; i < globals["numberOfAgents"]; i++) {
      let timeoutAgent = GetTimeoutAgents(i, agents[i].wait, maxTimeout);
      timeoutAgents.push(timeoutAgent);
    }
  }
  return timeoutAgents;
}

/**
 * Returns a List of inputLists, with the index of each list in correlation to the agentnames.
 * 
 * Note: it is important, that this function is the first one being called after the initialization
 * of the seed based pseudorandomnumber generator, because this way it can be ensured, that
 * all the different algorithms with the same numberOfAgents and seed will have the same inputs
 * for the same agents.
 */
function GetXValueLists() {
  const numberOfAgents = globals["numberOfAgents"];
  var xValueLists = [];
  for (let i = 0; i < numberOfAgents; i++) {
    let xValueList = [];
    for (let j = 0; j < globals["valueListSize"]; j++) {
      xValueList.push(random(globals["valueIntervalSize"]));
    }
    xValueLists.push(xValueList);
  }
  return xValueLists;
}


function GetGameMaster() {
  // Create Gamemaster
  let gamemaster = {
    "agent_name": "gamemaster",
    "behaviors": ["gamemaster.js"],
    "color": "black",
    "shape": "cone",
    "position": [radius + 6, 0, 1.5],
    "direction": [0, 0, 1],
    "resultLists": [],
    "scale": [3, 3, 3],
    "allMessages": []
  }
  return gamemaster;
}

/**
 * Starts test for distribution of messageDelay. Depends on
 * messageMaxDelay & delayFunction. Shows all possible values
 * for messageDelays as a plot of the heights of agents. If clicked
 * on one agent, the real delay can be seen under "delay".
 * 
 * The height and width of the agents is 
 */
function StartMessageDelayDistributionTest() {
  var agents = [];
  const maxDelay = globals["messageMaxDelay"];
  const maxHeightWeight = 15;
  const heightScale = maxHeightWeight / maxDelay;
  for (var i = 0; i < maxDelay + 1; i++) {
    var agent = {
      // STANDARD
      "agent_name": i,
      "behaviors": ["messageDelayDistributionTest.js"],
      "position": [i * heightScale - (maxHeightWeight / 2), 0, 0],
      "scale": [1, heightScale, 1],
    }
    agent.delay = getMessageDelay(i);
    agent.height = agent.delay * heightScale;
    agents.push(agent);
  }

  return agents;
}

/**
 * Due to Hash's lack of flexibility in setting up the globals,
 * there was the need to define a format that can be changed freely.
 * Therefore a string is being used and needs to be
 * interpreted in this function.
 * 
 */
function InitAgentDeathObject() {
  var agentDeathString = globals["agentDeaths"];
  agentDeaths = [];

  // If death is defined
  if (agentDeathString.length > 0) {
    let agentDeathSplit = agentDeathString.split(';');
    agentDeathSplit.forEach(agentDeath => {
      agentDeathS = agentDeath.split(',');
      agentDeaths[agentDeathS[0]] = agentDeathS[1];
    });
  }
}

/**
 * If an agentDeath is defined in agentDeaths, the death-date of the agent
 * is being set in this function.
 * 
 * @param{agent} agent 
 */
function DoomAgent(agent) {
  // If death is defined
  if (agentDeaths != null) {
    // Adding death
    let doomsday = agentDeaths[agent.agent_name];
    if (doomsday != null) {
      agent.deathRound = doomsday;
    }
  }
  return agent;
}
// #endregion

// #region Node Constructor Functions

function GetMultiBenOrAgent(agentID, xValueList) {
  let agent = {
    // STANDARD
    "agent_name": agentID,
    "behaviors": ["Multi_Ben_Or_Node.js"],
    "position": positionInCircle(radius, agentID),
    "scale": [1.6, 1.6, 1],
    "color": getColor(xValueList[0]),
    "height": globals["phase0Height"],
    // USER
    "phase": "p0",
    "round": 0,
    "globalRound": 0, // Round to work on values
    "xValueList": xValueList, // List instead of one value
    "x": xValueList[0],
    "decided": null,
    "decidedList": [],
    "Rmsg": [],
    "Pmsg": [],
    "allMessages": [],
  }
  return agent;
}


function GetMultiPaxosAgent(agentID, role, xValueList) {
  let agent = {
    // STANDARD
    "agent_name": agentID,
    "behaviors": ["Multi_Paxos_Node.js"],
    "position": positionInCircle(radius, agentID),
    "scale": [1.6, 1.6, 1],
    //"color": getColor(x, context),
    "height": globals["phase0Height"],
  }

  // Round/Phase settings
  agent.role = role;
  agent.phase = role == PROPOSER ? PHASE1 : PHASEACCEPTOR; // Starting Phase
  agent.color = globals["colorProposer"];
  agent.round = 0; // Starting round
  agent.globalRound = 0; // Round to work on values
  agent.leader = null; // No Leader selected yet
  // Values/Decision
  agent.xValueList = xValueList; // List instead of one value
  agent.x = xValueList[0]; // value to choose (first in List)
  agent.decided = null; // No value decided yet
  agent.decidedList = [];

  // All message arrays prepared to access and save
  agent.allMessages = [];
  agent.promisedMsgs = [];
  agent.acceptedMsgs = [];

  // Settings from globals
  agent.timeout = globals["messageMaxDelay"] * 2 + globals["timeoutConstant"];
  agent.wait = role == PROPOSER ? 1 : agent.timeout;

  return agent;
}

function GetMultiRaftAgent(agentID, xValueList, timeout) {
  let agent = {
    // STANDARD
    "agent_name": agentID,
    "behaviors": ["Multi_Raft_Node.js"],
    "position": positionInCircle(radius, agentID),
    "scale": [1.6, 1.6, 1],
    //"color": getColor(x, context),
    "height": globals["phase0Height"],
    // USER
    "xValueList": xValueList, // List instead of one value
    "x": xValueList[0],
    "decided": null,
    "decidedList": [],
    "allMessages": [],
    "leader": null,
    "color": globals["colorNoLeader"],
    "voteMessages": [],
  }
  agent.role = "follower";
  agent.term = 0;
  agent.decided = null;
  agent.allMessages = [];
  agent.leader = null;
  agent.globalRound = 0; // Round to work on values
  agent.voteMessages = [];
  agent.preparedMsgs = [];
  agent.acknowledgedMsgs = [];
  agent.timeout = timeout;
  agent.wait = agent.timeout;

  return agent;
}

function GetTimeoutList() {
  const numberOfAgents = globals["numberOfAgents"];
  var timeoutList = [];
  for (let i = 0; i < numberOfAgents; i++) {
    let randomValue = globals["messageMaxDelay"] * (i + 1) * 2 + globals["timeoutConstant"];
    //(messageMaxDelay * (i+1)) * 2 + timeoutConstant$
    timeoutList.push(Math.ceil(randomValue));
  }
  return shuffleArray(timeoutList);
}

/**
 * Creates
 * 
 * @param{number} agentID ID or name of agent
 * @param{number} agentTimeout Timout of agent
 */
function GetTimeoutAgents(agentID, agentTimeout, maxTimeout) {
  let d2Position = positionInCircle(radius + 1, agentID);
  let d3Position = [d2Position[0], d2Position[1], 0];
  let agent = {
    // STANDARD
    "agent_name": agentID + "_timeout",
    "behaviors": ["Timeout_Node.js"],
    "position": d3Position,
    "scale": [0.5, 0.5],
    "color": "white",
    "height": agentTimeout * globals["objectsMaxHeight"] / maxTimeout,
    "timeout": agentTimeout,
    "maxTimeout": maxTimeout,
    // USER
  }
  agent.wait = agent.timeout;

  return agent;
}


function GetInputvalueBlocks(xValueLists) {
  blockAgents = [];
  for (let i = 0; i < globals["numberOfAgents"]; i++) {
    var blockList = buildBinaryBlocks(xValueLists[i], positionInCircle(radius + 3, i));
    blockAgents = blockAgents.concat(blockList);
  }
  return blockAgents;
}

// #endregion

// region Helper functions

// region Random function
/**
 * Returns a random function based on seed from globals.
 * Created in 2018 by David Blackman and Sebastiano Vigna (vigna@acm.org)
 */
function xoshiro128ss() {
  let seed = cyrb128(globals["seed"]);
  a = seed[0];
  b = seed[1];
  c = seed[2];
  d = seed[3];

  // Random Function
  return function (num) {
    var t = b << 9, r = a * 5; r = (r << 7 | r >>> 25) * 9;
    c ^= a; d ^= b;
    b ^= c; a ^= d; c ^= t;
    d = d << 11 | d >>> 21;
    let randomNumber = (r >>> 0) / 4294967296;
    let randomInt = Math.floor(randomNumber * globals["randomScale"])
    return randomInt % num;
  }
}

/**
 * Hash function - Generates 4 hashes from seed to generate a random function.
 * Written in 01.12.2017 by bryc
 * https://stackoverflow.com/questions/521295/seeding-the-random-number-generator-in-javascript
 * https://github.com/bryc/code
 * 
 * @param{string} str seed
 */
function cyrb128(str) {
  let h1 = 1779033703;
  let h2 = 3144134277;
  let h3 = 1013904242;
  let h4 = 2773480762;
  for (let i = 0, k; i < str.length; i++) {
    k = str.charCodeAt(i);
    h1 = h2 ^ Math.imul(h1 ^ k, 597399067);
    h2 = h3 ^ Math.imul(h2 ^ k, 2869860233);
    h3 = h4 ^ Math.imul(h3 ^ k, 951274213);
    h4 = h1 ^ Math.imul(h4 ^ k, 2716044179);
  }
  h1 = Math.imul(h3 ^ (h1 >>> 18), 597399067);
  h2 = Math.imul(h4 ^ (h2 >>> 22), 2869860233);
  h3 = Math.imul(h1 ^ (h3 >>> 17), 951274213);
  h4 = Math.imul(h2 ^ (h4 >>> 19), 2716044179);

  a = (h1 ^ h2 ^ h3 ^ h4) >>> 0;
  b = (h2 ^ h1) >>> 0;
  c = (h3 ^ h1) >>> 0;
  d = (h4 ^ h1) >>> 0;
  return [a, b, c, d];
}
// endregion

// region global functions

/**
 * Initializes all global functions in stdlib.
 * (This is a small hack, to be able to use the same functions cross different files)
 */
function initGlobalFunctions() {
  globalThis.stdlib = {
    random,
    getMessageAgent,
    getMessageDelay,
    shuffleArray,
    positionInCircle,
    addPositions,
    getColor,
    updateTimeout,
    allMessagesUpdate,
    buildBinaryBlocks,
    killAgentOnCondition
  };
}

/**
 * Creates and gets an message agent.
 * 
 * @param{AgentState} state agentstate
 * @param{message} message to be sent
 * @param{string} reciever to send the message to
 */
function getMessageAgent(state, message, reciever) {
  let messageAgent = {
    // Hash parameters
    "agent_name": "msg_" + state.agent_name + "To" + reciever,
    "behaviors": ["msg.js"],
    "position": stdlib.addPositions(state.position, stdlib.positionInCircle(globals["message_distance"], reciever)),
    "scale": [0.5, 0.5],
    // User parameters
    "m": message,
    "round": state.round,
    "globalRound": state.globalRound,
    "positionTo": stdlib.positionInCircle(radius, reciever),
    "reciever": reciever,
    "wait": stdlib.getMessageDelay(),
    "type": message.type
  }

  const algorithm = globals["algorithm"];
  switch (algorithm) {
    case 0:
      messageAgent = getMultiBenOrMessageAgent(messageAgent);
      break;
    case 1:
      messageAgent = getMultiPaxosMessageAgent(state, messageAgent);
      break;
    case 2:
      messageAgent = getMultiRaftMessageAgent(state, messageAgent);
      break;
  }

  var height = messageAgent.height * 0.8;
  messageAgent.direction = [0, 0, 1];
  messageAgent.shape = "cylinder";
  messageAgent.scale = [0.5, height, 0.5];
  messageAgent.position = [messageAgent.position[0], messageAgent.position[1], height / 2];
  messageAgent.positionTo = [messageAgent.positionTo[0], messageAgent.positionTo[1], messageAgent.position[2]];
  messageAgent.height = 0.5;

  return messageAgent;
}

function getMultiBenOrMessageAgent(messageAgent) {
  messageAgent.color = getColor(messageAgent.m.data.value);
  messageAgent.height = messageAgent.m.data.type == "R" ? globals["phase1Height"] : globals["phase2Height"];
  messageAgent.value = messageAgent.m.data.value.value;
  messageAgent.type = messageAgent.m.type;
  messageAgent.Mathias = "hallo";
  return messageAgent;
}

/**
 * Set's the color, shape, position adjustment
 * 
 * @param {AgentState} state of the sending agent
 * @param {any} messageAgent messageAgent
 */
function getMultiPaxosMessageAgent(state, messageAgent) {
  messageAgent.color = state.color;
  let value = messageAgent.m.data.value;

  if (messageAgent.type == PREPARE) {
    messageAgent.height = globals["phase1Height"];
  } else if (messageAgent.type == PROMISE) {
    messageAgent.height = globals["phase1Height"];
    messageAgent.color = value ? "green" : "red";
  } else if (messageAgent.type == ACCEPT) {
    messageAgent.height = globals["phase2Height"];
    messageAgent.color = getColor(messageAgent.m.data.value);
  } else if (messageAgent.type == ACCEPTED) {
    messageAgent.height = globals["phase2Height"];
    messageAgent.color = value ? "green" : "red";
  }

  return messageAgent;
}


function getMultiRaftMessageAgent(state, messageAgent) {
  let value = messageAgent.m.data.value ?? true;

  // Follower message
  if (messageAgent.type == FollowerResponse || messageAgent.type == FollowerPrepare || messageAgent.type == FollowerAcknowledge) {
    messageAgent.color = value ? "green" : "red";
    if (messageAgent.type == FollowerResponse) {
      messageAgent.height = globals["phase0Height"];
    } else if (messageAgent.type == FollowerPrepare) {
      messageAgent.height = globals["phase1Height"];
    } else if (messageAgent.type == FollowerAcknowledge) {
      messageAgent.height = globals["phase2Height"];
    }
  }
  // Leader message
  else {
    messageAgent.height = state.height;
    if (messageAgent.type == LeaderRequest || messageAgent.type == LeaderPrepare) {
      messageAgent.color = state.color;
    }
    else if (messageAgent.type == LeaderAcknowledge) {
      messageAgent.color = getColor(messageAgent.m.data.value);
    }
  }
  // messageAgent.shape = "sphere";
  // messageAgent.height = 1;
  return messageAgent;
}

/**
 * Returns message delay.
 * 
 * Use of: random, messageMaxDelay, maxdelayFunction, 
 * 
 * random: function that returns int in range [0 - parameter-1]
 * 
 * messageMaxDelay: maximum delay the message is delayed
 * 
 * maxdelayFunction: distribution of randomness
 * 
 * @param{specificValue} specificValue for distribution. Parameter can be passed for
 * a specific value (as in delayDistributionTest) as randomValue. If empty (normally), it get#s
 * randomly set between 0 and messageMaxDelay
 */
function getMessageDelay(specificValue) {
  maxDelay = globals["messageMaxDelay"];
  randomValue = specificValue ?? random(maxDelay);

  let returnValue = 0;
  const functionType = globals["delayFunction"];
  switch (functionType) {
    // linear
    case "lin":
      returnValue = randomValue;
      break;
    // logarithmic (natural)
    case "log":
      var logScaleFactor = (maxDelay / Math.log(1 + maxDelay));
      var log = Math.log(1 + randomValue) * logScaleFactor;
      returnValue = Math.ceil(log);
      break;
    // exponential
    case "exp":
      var expScaleFactor = Math.exp(maxDelay);
      let exp = (Math.exp(randomValue) / expScaleFactor) * maxDelay;
      returnValue = Math.floor(exp);
      break;
    case "gaus":
      // gaussian function
      // the idea here is, to have a gauss bell function, that is scaled, so that input and output roughly range from 0 -> 100
      const gausParam = globals["g"];
      let randomValueShifted = randomValue / maxDelay - (1 / 2);
      let randomValueShiftedScaled = randomValueShifted * gausParam;
      let gausBellCurve = Math.exp(-(randomValueShiftedScaled * randomValueShiftedScaled));
      returnValue = Math.floor((maxDelay * gausBellCurve));
  }

  return returnValue;
}

/**
 * Simple shuffle for an array,
 * used to change the order of messages recieved for each agent.
 * 
 * @param{array} array array to be shuffled
 */
function shuffleArray(array) {
  if (globals["messageListRandomized"]) {
    for (var i = array.length - 1; i > 0; i--) {
      // Generate random number
      var j = random(array.length);
      var temp = array[i];
      array[i] = array[j];
      array[j] = temp;
    }
  }
  return array;
}

/**
 * Returns a position based on a circle, divided in equal parts through the number of agents.
 * 
 * @param{number} parameterRadius radius from [0,0]
 * @param{number} member_id ID for position in circle
 */
function positionInCircle(parameterRadius, member_id) {
  const numberOfAgents = globals["numberOfAgents"];
  const localRadius = parameterRadius;
  // divide circle equaly through number of agents
  const factor = ((2 * Math.PI) / numberOfAgents);
  // math comes from complex numbers
  let angle = factor * member_id;
  let real = localRadius * Math.cos(angle);
  let im = localRadius * Math.sin(angle);
  // 2D position
  let position = [real, im];
  return position;
}

/**
 * Adds to positions together to one
 * 
 * @param{array} position1 
 * @param{array} position2 
 */
function addPositions(position1, position2) {
  let x = position1[0] + position2[0];
  let y = position1[1] + position2[1];
  let position = [x, y];
  return position;
}

/**
 * Returns color based on given value.
 * -1 = red, 0 = color0 (globals), 1 = color1 (globals), else is green
 * 
 * @param {number} value (mostly) decision value of agent 
 */
function getColor(value) {
  switch (value) {
    case -1:
      return globals["colorUnkown"];
    case 0:
      return globals["color0"];
    case 1:
      return globals["color1"];
    case 2:
      return globals["color2"];
    default:
      return globals["colorUnkown"];
  }
}

/**
 * Updates timeout agents to animate in view. Only works, if "hideTimouts": false.
 * 
 * (Only visuals, no functionality)
 * 
 * @param{AgentState} state state for agentname and wait information.
 */
function updateTimeout(state) {
  let msg = {
    to: state.agent_name + "_timeout",
    type: "height",
    data: {
      value: state.wait,
    },
  };
  state.messages.push(msg);
}

/**
 * Updates all messages from an agents,
 * but filtered by globalRound for effiency.
 * 
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agen
 */
function allMessagesUpdate(state, context) {
  let oldAndNewMessages = state.allMessages.concat(context.messages());
  let filteredRelevantMessages = oldAndNewMessages.filter(m => m.data.globalRound >= state.globalRound - 1);
  state.allMessages = filteredRelevantMessages;
}

/**
 * Builds tower of binary values
 * 
 * @param{binaryList} binaryList
 * @param{position} position
 */
function buildBinaryBlocks(binaryList, position) {
  var index = 0;
  var blockList = [];
  var blockHeight = globals["objectsMaxHeight"] / binaryList.length;
  var dividerHeight = blockHeight * 1 / 5;
  binaryList.forEach(res => {

    var block = {
      "agent_name": "result_" + index,
      "position": [position[0], position[1], index * blockHeight + dividerHeight],
      "height": blockHeight - dividerHeight,
      "color": stdlib.getColor(res),
    };
    var divider = {
      "agent_name": "spacer_" + index,
      "position": [position[0], position[1], index * blockHeight],
      "height": dividerHeight,
      "color": globals["colorDivider"],
    };

    blockList = blockList.concat([divider, block]);
    index++;
  });
  return blockList;
}

/**
 * If one of the conditions is met, agent goes into his death phase.
 * 
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
function killAgentOnCondition(state, context) {
  // condition 1 is kill for round
  let cond1 = globals["deathByStepOrRound"] == "round" && state.deathRound != null && state.deathRound <= state.globalRound;
  // condition 2 is kill for step
  let cond2 = globals["deathByStepOrRound"] == "step" && state.deathRound != null && state.deathRound <= context.step();

  if (cond1 || cond2) {
    state.phase = PHASEDEAD;
    state.color = globals["colorDead"];
  }
  // RANDOM DYING
  else if (state.phase != PHASEDEAD && globals["randomDyingPercentage"] > 0) {
    let randomDieScale = Math.ceil((100 / globals["randomDyingPercentage"]));
    let randomNumber = random(randomDieScale);
    state.randomDieScale = randomDieScale;
    state.randomDieValue = randomNumber;
    if (0 == randomNumber) {
      state.deathCause = globals["randomDyingPercentage"] + " > " + randomNumber;
      state.phase = PHASEDEAD;
      state.color = globals["colorDead"];
    }
  }
}
// endregion
// endregion