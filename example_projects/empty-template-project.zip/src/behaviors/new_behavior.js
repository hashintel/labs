/**
 * Write a brief description of your behavior here.
 * 
 * This behavior will cause an agent to increase its height each step
 * until it reaches the max_height defined in globals.json
 */
const behavior = (state, context) => {
  // You can access agent properties by using state.get()
  let height = state.get("height");
  
  if (height < context.globals()["max_height"]) {
    height += 1;
  }

  // You can set agent properties using state.set()
  state.set("height", height);
};