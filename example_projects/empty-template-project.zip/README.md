This starter template shows how to use basic features of HASH.
It should provide direction in using common patterns and tools on the platform.
