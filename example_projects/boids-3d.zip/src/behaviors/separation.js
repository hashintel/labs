/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  const neighbors = context.neighbors();
  const { separation, separation_distance} = context.globals();

  // Throw warnings
  if (!state.position || !state.direction) {
    console.warn("Missing needed state", state);
    return;
  }

  // Separation: steer to avoid crowding local flockmates
  let sep_vec = [0, 0, 0];
  for (n of hash_stdlib.neighborsInRadius(state, neighbors, separation_distance, 0, true)) {
    state.position.forEach((p, i) => {
      const diff = p - n.position[i];
      sep_vec[i] += diff;
    })
  }

  // Calculate new direction
  state.direction = state.direction.map((d, i) =>
      d + (separation * sep_vec[i]));
};
