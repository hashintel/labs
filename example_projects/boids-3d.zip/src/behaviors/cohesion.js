/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  const neighbors = context.neighbors();

  // Throw warnings
  if (!state.position || !state.direction) {
    console.warn("Missing needed state", state);
    return;
  }

  // Cohesion: steer to move towards the average position (center of mass) of neighbors
  let avg_position = state.position;
  if (neighbors.length) {
    // Calculate the average position
    neighbors.forEach(n => {
      avg_position = avg_position.map((val, dim) => val + n.position[dim]);
    })
    avg_position = avg_position.map(item => item / (neighbors.length + 1)); // normalize
    
    // Calculate the direction from agent to center of mass
  }
  const cohesion_vec = state.position.map((v, dim) => avg_position[dim] - v);

  // Calculate new direction
  state.direction = state.direction.map((d, i) =>
      d + (context.globals().cohesion * cohesion_vec[i]));
};
