/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  // Throw warnings
  if (!state.position || !state.direction) {
    console.warn("Missing needed state", state);
    return;
  }

  // Normalize the direction vector:
  const magnitude = Math.sqrt(
      state.direction.reduce((acc, val) => acc + val ** 2, 0));
  state.direction = state.direction.map(v => v / magnitude);

  // Calculate new position based on the direction
  state.position = state.position.map((pos, i) => pos + state.direction[i]);
};
