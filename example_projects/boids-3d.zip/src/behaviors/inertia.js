/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  // Throw warnings
  if (!state.position || !state.direction) {
    console.warn("Missing needed state", state);
    return;
  }

  // Modify current direction
  state.original_direction = state.direction;
  state.direction = state.direction.map(d => 
      context.globals().inertia*d);
};
