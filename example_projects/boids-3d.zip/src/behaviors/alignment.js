/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  const neighbors = context.neighbors();

  // Throw warnings
  if (!state.position || !state.direction) {
    console.warn("Missing needed state", state);
    return;
  }

  // Alignment: steer along the average direction of neighbors
  let align_vec = state.original_direction;
  if (neighbors.length) {
    // Calculate the average direction
    neighbors.forEach(n => {
      align_vec = align_vec.map((val, dim) => val + n.direction[dim]);
    })
    align_vec = align_vec.map(item => item / (neighbors.length + 1)); // normalize
  
  }

  // Calculate new direction
  state.direction = state.direction.map((d, i) =>
      d + (context.globals().alignment * align_vec[i]));
};
