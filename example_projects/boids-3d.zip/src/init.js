/**
 * @param {InitContext} context for initialization
 */
const init = (context) => {
  // Dimension can be set to either 3 or 2 in globals.json
  const { dimension, agent_count, topology } = context.globals();
  
  // Returns a random normalized vector
  const randomVec = () => {
    const vec = Array(dimension).fill().map(() => (Math.random() - 0.5));
    const magnitude = Math.sqrt(vec.reduce((acc, val) => acc + val ** 2, 0));
    
    return vec.map(v => v / magnitude); // normalize the vector
  };

  // Returns a random RGB color
  const randomColor = () => {
    return Array(3).fill().map(() => Math.floor(Math.random() * 255));
  };

  const genAgent = () => ({
    direction: randomVec(),
    behaviors: [
      "inertia.js",
      "alignment.js",
      "cohesion.js",
      "separation.js",
      "move.js"
    ],
    rgb: randomColor(),
    shape: "bird"
  })

  return hstd.init.scatter(agent_count, topology, genAgent);
}
