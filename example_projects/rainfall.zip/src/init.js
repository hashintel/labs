/**
 * @param {InitContext} context for initialization
 */
const init = (context) => {
  const { topology, max_cell_height } = context.globals();

  const genAgent = () => ({
    "behaviors": ["@hash/diffusion/diffusion.rs", "@hash/age/age.rs", "switch_behaviors.js"],
    "height": Math.floor(Math.random() * max_cell_height),
    "color": "grey",
    "true_height": 0,
    "diffusion_targets": ["height"],
    "pooled": false,
    "age": 0
  })

  let agents = hstd.init.grid(topology, genAgent);

  // Add raincloud
  agents.push({
    "agent_name": "raincloud",
    "behaviors": ["raincloud.js", "@hash/age/age.rs"],
    "age": 0
  })

  return agents;
}
