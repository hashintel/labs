/**
 * @param {InitContext} context for initialization
 */
const init = (context) => {
  const { topology, agent_density, initial_sugar, 
      agent_vision, agent_metabolism } = context.globals();

  const { x_bounds, y_bounds } = topology;

  // Calculate number of agents
  const area = (x_bounds[1] - x_bounds[0]) * (y_bounds[1] - y_bounds[0]);
  const num_agents = Math.round(area * agent_density);

  // Create agents
  const genAgent = () => ({
    "type": "agent",
    "waiting": false,
    "color": "white",
    "height": 2,
    "behaviors": ["sugar_agent.js", "@hash/age/age.rs"],
    "sugar": hstd.stats.uniform.sample(...initial_sugar),
    "metabolism": hstd.stats.uniform.sample(...agent_metabolism),
    "search_radius": hstd.stats.uniform.sample(...agent_vision)
  });

  let agents = hstd.init.scatter(num_agents, topology, genAgent);

  // Create sugar patches
  // Import the dataset
  const sugarRows = context.data()["@hash/sugarscape-map/50x50.csv"];

  sugarRows.forEach((row, pos_x) => {
    row.forEach((cell, pos_y) => 
      agents.push({
        position: [pos_x, pos_y], // based on location in dataset
        max_sugar: parseInt(cell), // based on value in data
        sugar: parseInt(cell),
        height: 1,
        rgb: [255, 128, (255 * cell) / 5],
        behaviors: ["sugar_patch.js"]
      })
    )
  })

  // Add agent to calculate gini coefficient 
  agents.push({
    "behaviors": ["gini_calculator.js"],
    "search_radius": 50,
    "position": [25,25],
    "height": 0.01,
    "agent_name": "gini",
    "gini_value": 0
  })

  return agents;
}
