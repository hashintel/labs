A basic warehouse model. Items can be stored on "shelf" agents, and "worker" agents pick up and place items on the shelves and on the "dock" agents.

```video
https://cdn-us1.hash.ai/site/2020-11-06-09-57-40.mp4
```

### Poly model attribution
- Crate: [Dimension Virtual](https://poly.google.com/user/0oed5_QWBok)
- Forklift: [Colin McKibben](https://poly.google.com/user/3ZMwPuXjbtn)
