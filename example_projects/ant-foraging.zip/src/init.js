/**
 * @param {InitContext} context for initialization
 */
const init = (context) => {
  const { num_ants, topology} = context.globals();

  const genAnt = () => {
    const angle = Math.random() * 2 * Math.PI;

    return {
      position: [0, 0],
      angle,
      // Convert angle to direction
      direction: [Math.cos(angle), Math.sin(angle)],
      height: 1.5,
      behaviors: ["search.js", "wrap_angle.js", "move_in_direction", "eat.js"],
      color: "black",
      shape: "ant",
      search_radius: 1 
    }
  }

  const ants = hstd.init.stack(num_ants, genAnt);
  const pheromones = hstd.init.grid(topology, {
    "template_name": "pheromones",
    "height": 0.1,
    "behaviors": ["pheromone_field.js", "@hash/age/age.rs"],
    "strength": 0,
    "rgb": [230, 230, 250]
  });

  function createFoodPile(x, y) {
    // Create template pile
    const foodArray = Array(25).fill().map((_, ind) => ([ind % 5, Math.floor(ind/5)]));

    // Generate a pile of food with bottom left corner at [x,y]
    let foodLocs = foodArray.map(loc => [loc[0] + x, loc[1] + y]);
    foodLocs = foodLocs.concat([[x+1, y-1], [x+2, y-1], [x+3, y-1], [x+1, y+5], [x+2, y+5], [x+3, y+5]]);
    foodLocs = foodLocs.concat([[x-1, y+1], [x-1, y+2], [x-1, y+3], [x+5, y+1], [x+5, y+2], [x+5, y+3]]);
    
    return foodLocs.map(position => ({
      height: 1,
      behaviors: ["food.js"],
      color: "green",
      waiting: false,
      position,
      search_radius: 1
    }))
  }

  const food0 = createFoodPile(10, -11);
  const food1 = createFoodPile(-15, -11);
  const food2 = createFoodPile(-2, 12);

  const agents = [...ants, ...pheromones, ...food0, ...food1, ...food2];

  // Create nest
  agents.push({
    "agent_name": "nest",
    "position": [0, 0],
    "color": "yellow",
    "height": 2
  });

  return agents;
}
